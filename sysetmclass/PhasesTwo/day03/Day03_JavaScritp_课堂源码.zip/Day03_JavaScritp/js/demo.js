function demo1(){
	alert("Hello 外联的js代码执行了");
}